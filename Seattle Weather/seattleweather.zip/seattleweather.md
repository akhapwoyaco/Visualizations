```python

```

# Data import and cleaning


```python
import warnings
warnings.filterwarnings('ignore')
```


```python
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
```

i) Read the data in the fle SeattleWeather.csv into a pandas data frame called wx. How many rows
does wx have, and what are the column names.


```python
#reading the csv files
wx=pd.read_csv('SeattleWeather.csv',header=0)
```


```python
#Check first 5 rows
wx.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>NAME</th>
      <th>DATE</th>
      <th>AWND</th>
      <th>PRCP</th>
      <th>TAVG</th>
      <th>TMAX</th>
      <th>TMIN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USW00024233</td>
      <td>SEATTLE TACOMA AIRPORT, WA US</td>
      <td>2012-10-03</td>
      <td>16.33</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>66</td>
      <td>46</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USW00024233</td>
      <td>SEATTLE TACOMA AIRPORT, WA US</td>
      <td>2012-10-04</td>
      <td>14.54</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>66</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USW00024233</td>
      <td>SEATTLE TACOMA AIRPORT, WA US</td>
      <td>2012-10-05</td>
      <td>12.75</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>71</td>
      <td>48</td>
    </tr>
    <tr>
      <th>3</th>
      <td>USW00024233</td>
      <td>SEATTLE TACOMA AIRPORT, WA US</td>
      <td>2012-10-06</td>
      <td>11.41</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>75</td>
      <td>46</td>
    </tr>
    <tr>
      <th>4</th>
      <td>USW00024233</td>
      <td>SEATTLE TACOMA AIRPORT, WA US</td>
      <td>2012-10-07</td>
      <td>2.91</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>75</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

Number of Rows


```python
rows = len(wx.axes[0])#wx.shape[0]
print("The number of rows in wx data: ", rows)
```

    The number of rows in wx data:  2890
    


```python

```

Column Names


```python
print("Columns in Data wx: ")
for x in wx.columns:
    print(x)
```

    Columns in Data wx: 
    STATION
    NAME
    DATE
    AWND
    PRCP
    TAVG
    TMAX
    TMIN
    


```python

```

ii) Permanently remove the columns STATION and NAME from wx.


```python
#dropping the columns STATION and NAME from wx.
wx=wx.drop(['STATION','NAME'],axis=1)
```


```python

```

iii) Transform the DATE column to type datetime. In the function call, specify the date format explicitly.


```python
wx['DATE'] = pd.to_datetime(wx['DATE'])#Date time
```


```python
wx.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2890 entries, 0 to 2889
    Data columns (total 6 columns):
     #   Column  Non-Null Count  Dtype         
    ---  ------  --------------  -----         
     0   DATE    2890 non-null   datetime64[ns]
     1   AWND    2889 non-null   float64       
     2   PRCP    2890 non-null   float64       
     3   TAVG    2703 non-null   float64       
     4   TMAX    2890 non-null   int64         
     5   TMIN    2890 non-null   int64         
    dtypes: datetime64[ns](1), float64(3), int64(2)
    memory usage: 135.6 KB
    

## Exploratory Data Analysis

i) What is the highest value of wind speed (AWND) observed in the data set?


```python
highest_wind_speed = wx['AWND'].max()
print("highest value of wind speed (AWND) observed in the data set:",highest_wind_speed)
```

    highest value of wind speed (AWND) observed in the data set: 21.25
    


```python

```

ii) On what date was the lowest minimum temperature (TMIN) observed?


```python
column = wx["TMIN"]
#get index of min value
min_index = column.idxmin()
#print(min_index)
#get date
low_min_temp_date = wx.iloc[min_index, 0].date() #0 is DATE column index
print(low_min_temp_date, "had the lowest minimum temperature (TMIN) observed")
```

    2013-12-07 had the lowest minimum temperature (TMIN) observed
    


```python

```

iii) On how many days was the wind speed (AWND) smaller than 5 mph, and what was the average
maximum temperature (TMAX) over those days?


```python
new_df = wx[(wx.AWND < 5)]
#print(new_df)
#days
num_days_awnd5 = len(new_df['DATE'])
print("For",num_days_awnd5, "days the wind speed (AWND) smaller than 5 mph")
#Average
average_tmax_awnd5 = new_df["TMAX"].mean()
print("The average maximum temperature (TMAX) over days the wind speed (AWND) smaller than 5 mph was ",
      average_tmax_awnd5)
```

    For 555 days the wind speed (AWND) smaller than 5 mph
    The average maximum temperature (TMAX) over days the wind speed (AWND) smaller than 5 mph was  60.50990990990991
    


```python

```

iv) Create and display a new pandas data frame named prcp, with two columns called year and rain.
The rain column should contain the total (summed) precipitation amount (PRCP) per year. Then
visualise the total precipitation amount per year with a bar chart.


```python
prcp = wx[['DATE','PRCP']].copy()
prcp['DATE'] = prcp["DATE"].dt.strftime('%Y')
```


```python
prcp = prcp.groupby(['DATE']).sum().reset_index()
```


```python
prcp = prcp.rename(columns={'DATE':'Year','PRCP':'Rain'})
prcp.columns
```




    Index(['Year', 'Rain'], dtype='object')




```python
prcp
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Rain</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012</td>
      <td>21.84</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2013</td>
      <td>32.56</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2014</td>
      <td>48.50</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015</td>
      <td>44.83</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016</td>
      <td>45.18</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2017</td>
      <td>47.87</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2018</td>
      <td>35.73</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2019</td>
      <td>33.88</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2020</td>
      <td>24.03</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
plt.figure(figsize=(9,5))
plt.bar(prcp['Year'],prcp['Rain'] , align='center', alpha=0.5)
plt.xticks(np.arange(prcp.shape[0]), prcp['Year'])
plt.ylabel('TOTAL RAIN')
plt.title('ANNUAL TOTAL PRECIPITATION')
plt.savefig('ANNUAL TOTAL PRECIPITATION.png')
plt.show()
```


    
![png](output_36_0.png)
    



```python

```

## Regression modelling

i) Create a scatter plot of maximum temperature (TMAX) versus minimum temperature (TMIN). Using
the appropriate function from Scikit-Learn, ft a linear regression model to maximum temperature,
using minimum temperature as the covariate. Add the ftted regression line to the scatter plot.


```python

```


```python
#scatter plot of maximum temperature (TMAX) versus minimum temperature (TMIN)
plt.figure(figsize=(9,6))
plt.scatter(x = wx['TMIN'],y = wx['TMAX'])
plt.ylabel('maximum temperature (TMAX)')
plt.xlabel('minimum temperature (TMIN)')
plt.title('maximum temperature (TMAX) versus minimum temperature (TMIN)')
plt.savefig('max_min_temperature.png')
plt.show()
```


    
![png](output_41_0.png)
    



```python

```


```python
# Using the appropriate function from Scikit-Learn, ft a linear regression model to maximum temperature,
#using minimum temperature as the covariate
from sklearn import linear_model
#
length = wx.shape[0]
x = wx['TMIN'].values
y = wx['TMAX'].values
#
x = x.reshape(length, 1)
y = y.reshape(length, 1)
# Create linear regression object
regr = linear_model.LinearRegression()
# Train the model using the training sets
regr.fit(x,y)

# Add the ftted regression line to the scatter plot
plt.figure(figsize=(9,6))
plt.scatter(x,y, color = 'black')
plt.plot(x, regr.predict(x), color='blue', linewidth=3)
plt.ylabel('Predicted maximum temperature (TMAX)')
plt.xlabel('minimum temperature (TMIN)')
plt.title('Predicted maximum temperature (TMAX) versus minimum temperature (TMIN)')
plt.savefig('max_min_temperature_regression.png')
plt.show()
```


    
![png](output_43_0.png)
    



```python

```

ii) The slope coefcient of the regression line is larger than one - What does this tell us about the behavior
of daily temperature ranges in cold vs warm periods?


```python
# The coefficients
print('Coefficients: ', regr.coef_[0][0])
```

    Coefficients:  1.2957435385312708
    


```python
print('\n',
'A unit increase in the minimum temperatures, leads to a', regr.coef_[0][0],
'unit increase in the maximum temperatures.','\n',
'As such there in an increase in maximum temperatures as minimum temperature rise,','\n',
'with the ranges fairly remaining the same in both cold and warmer periods')
```

    
     A unit increase in the minimum temperatures, leads to a 1.2957435385312708 unit increase in the maximum temperatures. 
     As such there in an increase in maximum temperatures as minimum temperature rise, 
     with the ranges fairly remaining the same in both cold and warmer periods
    


```python

```

## Model selection

### Fit two regression models to maximum temperature (TMAX)


```python

```

#### One model that only uses minimum temperature (TMIN) as the covariate


```python

```


```python
#Copy of data
wx_1 = wx.copy()
#using minimum temperature as the covariate
from sklearn import linear_model
#
length = wx_1.shape[0]
x = wx_1['TMIN'].values
y = wx_1['TMAX'].values
#
x = x.reshape(length, 1)
y = y.reshape(length, 1)
# Create linear regression object
regr = linear_model.LinearRegression()
# Train the model using the training sets
regr.fit(x,y)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;LinearRegression<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.linear_model.LinearRegression.html">?<span>Documentation for LinearRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>LinearRegression()</pre></div> </div></div></div></div>




```python
# residual sum of squares SSres 
residuals_y_tmin = y - regr.predict(x)
residuals_squared_tmin = residuals_y_tmin**2
residual_sum_squares_tmin = residuals_squared_tmin.sum()
print('The residual sum of squares (SSres):',residual_sum_squares_tmin)
```

    The residual sum of squares (SSres): 111278.96105148121
    


```python
#total sum of squares SStot 
deviation_y_tmin = y - y.mean()
deviation_squared_tmin = deviation_y_tmin**2
total_sum_squares_tmin = deviation_squared_tmin.sum()
print('The total sum of squares SStot:',total_sum_squares_tmin)
```

    The total sum of squares SStot: 509021.32214532874
    


```python
# The adjusted R2
n = len(x)#n is the sample size
p = 1 # p is the number of covariates
adjusted_R2_tmin = 1 - ( ((n-1)*residual_sum_squares_tmin)/ ((n-p-1)*total_sum_squares_tmin) )
print("The adjusted R Squared (R2):", adjusted_R2_tmin)
```

    The adjusted R Squared (R2): 0.7813107473012528
    


```python

```

#### Another model that uses minimum temperature (TMIN) and wind speed (AWND) as two covariates


```python
#Copy of data
wx_2 = wx.copy()

#using minimum temperature and wind speed as the covariate
from sklearn import linear_model
#
wx_2 = wx_2.dropna(subset=['TMIN','AWND'])
x = wx_2[['TMIN','AWND']]#x.reshape(length, 1)
y = wx_2['TMAX']#y.reshape(length, 1)
# Create linear regression object
regr = linear_model.LinearRegression()
# Train the model using the training sets
regr.fit(x,y)
```




<style>#sk-container-id-2 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-2 {
  color: var(--sklearn-color-text);
}

#sk-container-id-2 pre {
  padding: 0;
}

#sk-container-id-2 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-2 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-2 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-2 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-2 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-2 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-2 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-2 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-2 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-2 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-2 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-2 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-2 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-2 div.sk-label label.sk-toggleable__label,
#sk-container-id-2 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-2 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-2 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-2 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-2 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-2 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-2 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-2 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-2 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-2 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;LinearRegression<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.linear_model.LinearRegression.html">?<span>Documentation for LinearRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>LinearRegression()</pre></div> </div></div></div></div>




```python
# residual sum of squares SSres 2 covariates
residuals_y_tmin_awnd = y - regr.predict(x)
residuals_squared_tmin_awnd = residuals_y_tmin_awnd**2
residual_sum_squares_tmin_awnd = residuals_squared_tmin_awnd.sum()
print('The residual sum of squares (SSres):',residual_sum_squares_tmin_awnd)
```

    The residual sum of squares (SSres): 106090.14434102646
    


```python
#total sum of squares SStot 2 covariates
deviation_y_tmin_awnd = y - y.mean()
deviation_squared_tmin_awnd = deviation_y_tmin_awnd**2
total_sum_squares_tmin_awnd = deviation_squared_tmin_awnd.sum()
print('The total sum of squares SStot:',total_sum_squares_tmin_awnd)
```

    The total sum of squares SStot: 508936.74835583253
    


```python
# The adjusted R2 2 covariates
n = len(x)#n is the sample size
p = 2 # p is the number of covariates
adjusted_R2_tmin_awnd = 1 - ( ((n-1)*residual_sum_squares_tmin_awnd)/ ((n-p-1)*total_sum_squares_tmin_awnd) )
print("The adjusted R Squared (R2):", adjusted_R2_tmin_awnd)
```

    The adjusted R Squared (R2): 0.7914010626516027
    


```python

```

#### Finally, based on your R2 a calculations, state your preference which of the two ftted regression models is better.


```python
print('\n',
    "The adjusted R Squared (R2) for model that uses minimum temperature (TMIN) as the covariate is", '\n', 
    adjusted_R2_tmin,'\n', 
    "The adjusted R Squared (R2) for model that uses minimum temperature (TMIN) and wind speed (AWND)",
    "as two covariates: ", '\n',adjusted_R2_tmin_awnd, '\n', 
    "The preferred model is the model that uses minimum temperature (TMIN) and wind speed (AWND) as two covariates.")
```

    
     The adjusted R Squared (R2) for model that uses minimum temperature (TMIN) as the covariate is 
     0.7813107473012528 
     The adjusted R Squared (R2) for model that uses minimum temperature (TMIN) and wind speed (AWND) as two covariates:  
     0.7914010626516027 
     The preferred model is the model that uses minimum temperature (TMIN) and wind speed (AWND) as two covariates.
    


```python

```

## Graphical summary


```python
wx_3 = wx[['DATE','PRCP','TMAX','TMIN']].copy()
```


```python
wx_3.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DATE</th>
      <th>PRCP</th>
      <th>TMAX</th>
      <th>TMIN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012-10-03</td>
      <td>0.0</td>
      <td>66</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Get Year column
wx_3['YEAR_MONTH'] = wx_3['DATE'].dt.strftime("%Y-%m")
#Drop Date Column
wx_3=wx_3.drop(['DATE'],axis=1)
wx_3['YEAR'] = wx_3['YEAR_MONTH'].apply(lambda x: x[0:4])
wx_3 = wx_3[(wx_3.YEAR == '2015')]
wx_3['MONTH'] = wx_3['YEAR_MONTH'].apply(lambda x: int(x[-2:]))
#Drop Date Column
wx_3=wx_3.drop(['YEAR_MONTH'],axis=1)
```


```python
#The precipitation amounts sum totals
prcp_sum = wx_3.groupby(['MONTH'])['PRCP'].sum().reset_index()
prcp_sum
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MONTH</th>
      <th>PRCP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3.66</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>5.27</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>4.47</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2.03</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0.58</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>0.23</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>0.09</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>3.28</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>0.83</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>4.81</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>8.37</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>11.21</td>
    </tr>
  </tbody>
</table>
</div>




```python
#The Temperature values shown are averages
temp_ave = wx_3.groupby(['MONTH'])[['TMAX','TMIN']].mean().reset_index()
temp_ave
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MONTH</th>
      <th>TMAX</th>
      <th>TMIN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>50.290323</td>
      <td>39.838710</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>54.535714</td>
      <td>42.964286</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>57.870968</td>
      <td>43.161290</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>59.900000</td>
      <td>42.833333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>68.032258</td>
      <td>50.225806</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>78.900000</td>
      <td>56.433333</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>82.580645</td>
      <td>59.903226</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>78.967742</td>
      <td>58.451613</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>68.533333</td>
      <td>52.466667</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>63.580645</td>
      <td>50.903226</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>49.433333</td>
      <td>38.233333</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>47.064516</td>
      <td>38.870968</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
fig, ax  = plt.subplots(figsize=(9,5))
plt.title('Climograph for Seattle, 2015 ')

ax2 = ax.twinx()
ax.bar(prcp_sum['MONTH'],prcp_sum['PRCP'], align='center', alpha=0.5, label = 'PRCP')
ax.legend(loc=0)

#Line Plots
ax2.plot(prcp_sum['MONTH'], temp_ave['TMAX'], label='TMAX', color = "red")
ax2.plot(prcp_sum['MONTH'], temp_ave['TMIN'], label='TMIN', color = "blue")

#labels to axis
#Primary axis
ax.set_ylabel('Total Precipitation(inch)')
ax.set_xlabel('Month')

#Secondary y-axis label
ax2.set_ylabel('Avg. Temperature (F)')
plt.legend()
plt.savefig('climatography_seattle.png')
plt.show()
```


    
![png](output_75_0.png)
    



```python

```
